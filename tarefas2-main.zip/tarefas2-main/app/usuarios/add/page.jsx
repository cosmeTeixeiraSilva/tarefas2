import React from "react";

export default function Cadastrar_user() {
  return (
    <div className="w-full flex flex-col items-center justify-center mt-12 ">
      <p className="mb-4 font-semibold">Cadastro de Usuário:</p>
    </div>
  );
}
