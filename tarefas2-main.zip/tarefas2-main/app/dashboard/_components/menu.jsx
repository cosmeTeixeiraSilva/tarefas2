import React from "react";

export default function Menu_dash() {
  return <div></div>;
}
